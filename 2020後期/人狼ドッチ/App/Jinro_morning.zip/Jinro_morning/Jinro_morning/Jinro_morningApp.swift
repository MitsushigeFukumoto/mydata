//
//  Jinro_morningApp.swift
//  Jinro_morning
//
//  Created by Mitsushige Fukumoto on 2020/10/06.
//

import SwiftUI

@main
struct Jinro_morningApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
