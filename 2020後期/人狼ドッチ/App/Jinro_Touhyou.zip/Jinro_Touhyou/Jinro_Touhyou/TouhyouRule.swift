//
//  TouhyouRule.swift
//  Jinro_Touhyou
//
//  Created by Mitsushige Fukumoto on 2020/11/02.
//

import SwiftUI

struct TouhyouRule: View {
    var body: some View {
        ZStack{
            //Background
            Rectangle()//赤
                .foregroundColor(Color(red: 100/255, green: 20/255, blue: 0/255))
                .edgesIgnoringSafeArea(.all)
            
            VStack{
                Text("追放投票")
                    .font(.system(size: 30))
                    .frame(width: 300, height: 100, alignment: .center)
                    .background(Color.white)
                    .cornerRadius(20.0)
                Spacer()
                Text("これより追放投票を行います。\n人狼が追放されると市民チームの勝利\n市民側（裏切り者含む）が追放されると人狼チームの勝利\nおばけが追放されるとおばけの１人勝ちとなります。\nメインカードに人狼チームのカードを持っている人がいないと思う場合は平和村を選択するとができます。")
                    .font(.system(size: 20))
                    .frame(width: 340, height: 300, alignment: .center)
                    .background(Color.white)
                    .cornerRadius(20.0)
                    .padding(.vertical)
                Spacer()
                
                NavigationLink(destination: TouhyouSelect()){
                    Text("OK")
                        .bold()
                        .font(.system(size: 30))
                        .frame(width: 190, height: 100, alignment: .center)
                        .foregroundColor(.black)
                        .background(Color.white)
                        .cornerRadius(20.0)
                }
                Spacer()
                    .frame(width: 100, height: 200, alignment: .center)
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct TouhyouRule_Previews: PreviewProvider {
    static var previews: some View {
        TouhyouRule()
    }
}
