//
//  TouhouSelect.swift
//  Jinro_Touhyou
//
//  Created by Mitsushige Fukumoto on 2020/11/03.
//

import SwiftUI

struct TouhouSelect: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TouhouSelect_Previews: PreviewProvider {
    static var previews: some View {
        TouhouSelect()
    }
}
