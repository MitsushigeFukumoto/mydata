//
//  Jinro_TouhyouApp.swift
//  Jinro_Touhyou
//
//  Created by Mitsushige Fukumoto on 2020/11/02.
//

import SwiftUI

@main
struct Jinro_TouhyouApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
