//
//  Jinro_RuleApp.swift
//  Jinro_Rule
//
//  Created by Mitsushige Fukumoto on 2020/11/03.
//

import SwiftUI

@main
struct Jinro_RuleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
