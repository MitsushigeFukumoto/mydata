//
//  HelloWorld.swift
//  Jinro_morning
//
//  Created by Mitsushige Fukumoto on 2020/11/02.
//

import SwiftUI

struct HelloWorld: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct HelloWorld_Previews: PreviewProvider {
    static var previews: some View {
        HelloWorld()
    }
}
